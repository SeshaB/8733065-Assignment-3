const Order = require("./4-Order");

const OrderState = Object.freeze({
    WELCOMING:   Symbol("welcoming"),
    SIZE:   Symbol("size"),
    TOPPINGS:   Symbol("toppings"),
    BRIYANI: Symbol("briyani"),
    NAAN: Symbol("naan"),
    DRINKS:  Symbol("drinks")
});

module.exports = class PizzaOrder extends Order{
    constructor(){
        super();
        this.stateCur = OrderState.WELCOMING;
        this.sSize = "";
        this.sToppings = "";
        this.sBRIYANI = "";
        this.sDrinks = "";
        this.sNaan = "";
        this.sItem = "Briyani";
    }
    handleInput(sInput){
        let aReturn = [];
        switch(this.stateCur){
            case OrderState.WELCOMING:
                this.stateCur = OrderState.SIZE;
                this.sBRIYANI = sInput;
                aReturn.push("Welcome to Briyani House");
                aReturn.push("choose your Briyani Type");
                aReturn.push(" Chicken");
                aReturn.push(" Mutton");
                aReturn.push(" Egg");
                break;
            case OrderState.SIZE:
                this.stateCur = OrderState.SIZEE
                this.sSize = sInput;
                aReturn.push("What would you like to have a Starters");
                aReturn.push("Chicken -65");
                aReturn.push("Chicken Lollypop");
                aReturn.push("Fish Finger");
                break;
            case OrderState.SIZEE:
                this.stateCur = OrderState.NAAN
                this.sSizee = sInput;
                aReturn.push("What would you like to have a second meal");
                aReturn.push("Naan");
                aReturn.push("Parotha");
                aReturn.push("Wheat Parotha");
                break;
            case OrderState.NAAN:
                this.stateCur = OrderState.TOPPINGS
                this.sNaan = sInput;
                aReturn.push("What would you like to have a Gravy with it");
                aReturn.push("Chicken Tikka");
                aReturn.push("Butter Chicken");
                aReturn.push("Garlic Chicken");
                break;
            case OrderState.TOPPINGS:
                this.stateCur = OrderState.DRINKS
                this.sToppings = sInput;
                aReturn.push("Would you like drinks with that?");
                break;

            case OrderState.DRINKS:
                this.isDone(true);
                if(sInput.toLowerCase != "no"){
                    this.sDrinks = sInput;
                }
                aReturn.push("Thank-you for your order of");
                aReturn.push(`${this.sSize} ${this.sItem}  ${this.sSizee} with ${this.sToppings} Gravy ${this.sNaan} `);
                if(this.sDrinks){
                    aReturn.push(this.sDrinks);
                }
                let d = new Date(); 
                d.setMinutes(d.getMinutes() + 20);
                aReturn.push(`Please pick it up at ${d.toTimeString()} and the Total of $43.24**`);
                break;
        }
        return aReturn;
    }
}